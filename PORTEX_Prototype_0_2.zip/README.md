# PORTEX Launcher — Preview 0.2

Protótipo Android em Kotlin + Jetpack Compose.

## O que funciona nesta prévia
- Navegação entre Início, Biblioteca, Controles e Ajustes.
- Biblioteca de jogos persistente (sobrevive ao fechar o app).
- Importação de arquivo pelo seletor do Android (guarda o acesso ao arquivo).
- Perfil por jogo: gráficos (Automático, DXVK, VKD3D-Proton, VirGL) e resolução.
- Uma pasta isolada por jogo em `files/prefixes/<id>` (futuro prefixo Wine).
- Remover jogo apaga o perfil e a pasta isolada.

## O que ainda NÃO funciona
- Não executa arquivos EXE.
- Não inclui Wine, Box64, DXVK ou VKD3D (as opções de gráficos só são salvas).
- Controles virtuais e editor de layout ainda não existem.

## Estrutura
- `data/` — modelos (`Game`, `GameProfile`) e `GameRepository`.
- `ui/` — tema, Início, Biblioteca e telas provisórias.

## Como compilar
Android Studio com SDK 35 e JDK 17, ou o workflow do GitHub Actions.
O APK de debug fica em `app/build/outputs/apk/debug/`.
