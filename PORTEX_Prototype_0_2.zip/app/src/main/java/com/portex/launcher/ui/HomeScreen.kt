package com.portex.launcher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun HomeScreen(gameCount: Int, onImport: () -> Unit, modifier: Modifier = Modifier) {
    LazyColumn(
        modifier = modifier.padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Spacer(Modifier.height(18.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("PORTEX", fontSize = 27.sp, fontWeight = FontWeight.Black, color = Color.White)
                        Text(
                            "ANDROID GAME HUB  •  PREVIEW 0.2",
                            fontSize = 9.sp, color = PortexColors.Muted, letterSpacing = 1.4.sp
                        )
                    }
                    Surface(shape = RoundedCornerShape(50), color = Color(0xFF20263A)) {
                        Text(
                            "●  DEMO", color = PortexColors.AccentSoft, fontSize = 10.sp,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                        )
                    }
                }
            }
        }
        item {
            Surface(color = PortexColors.Panel, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("SEU PRÓXIMO JOGO COMEÇA AQUI", color = PortexColors.Muted, fontSize = 10.sp, letterSpacing = 1.2.sp)
                    Text("Jogue do seu jeito.", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "Organize seus jogos, ajuste um perfil para cada um e deixe tudo pronto.",
                        color = PortexColors.Muted, fontSize = 13.sp
                    )
                    Button(
                        onClick = onImport,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = PortexColors.Accent),
                        shape = RoundedCornerShape(13.dp)
                    ) {
                        Icon(Icons.Default.Add, null)
                        Spacer(Modifier.width(8.dp))
                        Text("ADICIONAR JOGO")
                    }
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SectionLabel("VISÃO GERAL")
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard("JOGOS", "%02d".format(gameCount), Modifier.weight(1f))
                    StatCard("PERFIL", "PADRÃO", Modifier.weight(1f))
                    StatCard("MOTOR", "DEMO", Modifier.weight(1f))
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                SectionLabel("STATUS DO PROJETO")
                StatusRow("Interface PORTEX", "PRONTA", true)
                StatusRow("Biblioteca de jogos", "PRONTA", true)
                StatusRow("Perfis por jogo", "BÁSICO", true)
                StatusRow("Controles virtuais", "EM DESENVOLVIMENTO", false)
                StatusRow("Wine / Box64", "NÃO INTEGRADO", false)
                StatusRow("Execução de jogos Windows", "NÃO DISPONÍVEL", false)
            }
        }
        item {
            Text(
                "PORTEX  •  CONCEITO INICIAL", color = PortexColors.Muted, fontSize = 10.sp,
                modifier = Modifier.padding(vertical = 12.dp)
            )
        }
    }
}

@Composable
fun SectionLabel(text: String) {
    Text(text, color = PortexColors.Muted, fontSize = 11.sp, letterSpacing = 1.3.sp)
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier = modifier, color = PortexColors.Panel, shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(12.dp)) {
            Text(title, color = PortexColors.Muted, fontSize = 9.sp)
            Spacer(Modifier.height(5.dp))
            Text(value, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun StatusRow(name: String, status: String, ready: Boolean) {
    Row(
        Modifier.fillMaxWidth().background(PortexColors.Panel, RoundedCornerShape(12.dp)).padding(13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(name, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Text(status, color = if (ready) PortexColors.AccentSoft else PortexColors.Muted, fontSize = 9.sp)
        }
        Icon(
            if (ready) Icons.Default.CheckCircle else Icons.Default.Schedule, null,
            tint = if (ready) PortexColors.Accent else PortexColors.Muted,
            modifier = Modifier.size(18.dp)
        )
    }
}
