package com.portex.launcher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.portex.launcher.data.Game
import com.portex.launcher.data.GameProfile
import com.portex.launcher.data.GraphicsApi
import com.portex.launcher.data.Resolution
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(
    games: List<Game>,
    onImport: () -> Unit,
    onUpdateProfile: (Game, GameProfile) -> Unit,
    onRemove: (Game) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedId by remember { mutableStateOf<String?>(null) }
    val selected = games.firstOrNull { it.id == selectedId }

    Column(modifier.padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(18.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                SectionLabel("SUA BIBLIOTECA")
                Text("Seus jogos", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            }
            if (games.isNotEmpty()) {
                FilledTonalButton(
                    onClick = onImport,
                    colors = ButtonDefaults.filledTonalButtonColors(containerColor = PortexColors.Accent)
                ) {
                    Icon(Icons.Default.Add, null, tint = Color.White)
                    Spacer(Modifier.width(6.dp))
                    Text("ADICIONAR", color = Color.White, fontSize = 12.sp)
                }
            }
        }
        Spacer(Modifier.height(16.dp))

        if (games.isEmpty()) {
            EmptyLibrary(onImport)
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                items(games, key = { it.id }) { game ->
                    GameCard(game) { selectedId = game.id }
                }
            }
        }
    }

    if (selected != null) {
        ModalBottomSheet(
            onDismissRequest = { selectedId = null },
            containerColor = PortexColors.Panel
        ) {
            GameSheet(
                game = selected,
                onUpdateProfile = onUpdateProfile,
                onRemove = {
                    onRemove(selected)
                    selectedId = null
                }
            )
        }
    }
}

@Composable
private fun EmptyLibrary(onImport: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(top = 48.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Icon(Icons.Default.SportsEsports, null, tint = PortexColors.Accent, modifier = Modifier.size(56.dp))
        Text("Sua biblioteca está vazia", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        Text(
            "Adicione o arquivo de um jogo para começar.",
            color = PortexColors.Muted, fontSize = 13.sp, textAlign = TextAlign.Center
        )
        Button(
            onClick = onImport,
            colors = ButtonDefaults.buttonColors(containerColor = PortexColors.Accent),
            shape = RoundedCornerShape(13.dp)
        ) {
            Icon(Icons.Default.Add, null)
            Spacer(Modifier.width(8.dp))
            Text("ADICIONAR JOGO")
        }
    }
}

@Composable
private fun GameCard(game: Game, onClick: () -> Unit) {
    val hue = Math.floorMod(game.name.hashCode(), 360).toFloat()
    val c1 = Color.hsv(hue, 0.55f, 0.55f)
    val c2 = Color.hsv((hue + 40f) % 360f, 0.7f, 0.25f)

    Column(
        Modifier
            .clip(RoundedCornerShape(18.dp))
            .background(PortexColors.Panel)
            .clickable(onClick = onClick)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(1.1f)
                .background(Brush.linearGradient(listOf(c1, c2))),
            contentAlignment = Alignment.Center
        ) {
            Text(
                game.name.firstOrNull()?.uppercase() ?: "?",
                fontSize = 44.sp, fontWeight = FontWeight.Black, color = Color.White.copy(alpha = 0.9f)
            )
            Surface(
                modifier = Modifier.align(Alignment.TopEnd).padding(8.dp),
                shape = RoundedCornerShape(50),
                color = Color(0x99000000)
            ) {
                Text(
                    game.fileType, color = Color.White, fontSize = 9.sp,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                )
            }
        }
        Column(Modifier.padding(12.dp)) {
            Text(
                game.name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(
                "Controles: ${game.profile.controlsLayout}",
                color = PortexColors.Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun GameSheet(
    game: Game,
    onUpdateProfile: (Game, GameProfile) -> Unit,
    onRemove: () -> Unit
) {
    val date = remember(game.addedAt) {
        SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(game.addedAt))
    }
    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Column {
            Text(game.name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("${game.fileType}  •  adicionado em $date", color = PortexColors.Muted, fontSize = 12.sp)
        }

        OptionGroup(
            title = "GRÁFICOS",
            options = GraphicsApi.values().toList(),
            selected = game.profile.graphics,
            label = { it.label }
        ) { onUpdateProfile(game, game.profile.copy(graphics = it)) }

        OptionGroup(
            title = "RESOLUÇÃO",
            options = Resolution.values().toList(),
            selected = game.profile.resolution,
            label = { it.label }
        ) { onUpdateProfile(game, game.profile.copy(resolution = it)) }

        Text(
            "Layout de controles: ${game.profile.controlsLayout} (editor em breve)",
            color = PortexColors.Muted, fontSize = 12.sp
        )

        Button(
            onClick = {},
            enabled = false,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(13.dp)
        ) {
            Text("JOGAR  •  MOTOR AINDA NÃO INTEGRADO")
        }
        TextButton(onClick = onRemove, modifier = Modifier.fillMaxWidth()) {
            Text("Remover da biblioteca", color = PortexColors.Danger)
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun <T> OptionGroup(
    title: String,
    options: List<T>,
    selected: T,
    label: (T) -> String,
    onSelect: (T) -> Unit
) {
    Column {
        SectionLabel(title)
        options.forEach { option ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { onSelect(option) },
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(
                    selected = option == selected,
                    onClick = { onSelect(option) },
                    colors = RadioButtonDefaults.colors(
                        selectedColor = PortexColors.Accent,
                        unselectedColor = PortexColors.Muted
                    )
                )
                Text(label(option), color = Color.White, fontSize = 14.sp)
            }
        }
    }
}
