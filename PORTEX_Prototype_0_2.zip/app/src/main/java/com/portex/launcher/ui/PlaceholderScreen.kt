package com.portex.launcher.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun PlaceholderScreen(
    eyebrow: String,
    title: String,
    body: String,
    planned: List<String>,
    modifier: Modifier = Modifier
) {
    Column(
        modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Spacer(Modifier.height(18.dp))
        Text(eyebrow, color = PortexColors.Muted, fontSize = 10.sp, letterSpacing = 1.2.sp)
        Text(title, color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text(body, color = PortexColors.Muted, fontSize = 13.sp)
        Spacer(Modifier.height(4.dp))
        SectionLabel("PLANEJADO")
        planned.forEach { StatusRow(it, "EM BREVE", false) }
    }
}
