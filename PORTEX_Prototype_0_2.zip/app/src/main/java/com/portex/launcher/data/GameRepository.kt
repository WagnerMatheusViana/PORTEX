package com.portex.launcher.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/**
 * Guarda a biblioteca em SharedPreferences (JSON) e cria uma pasta isolada por jogo,
 * que no futuro será o prefixo Wine daquele jogo.
 */
class GameRepository(private val context: Context) {

    private val prefs = context.getSharedPreferences("portex_library", Context.MODE_PRIVATE)

    fun prefixDir(gameId: String): File = File(context.filesDir, "prefixes/$gameId")

    fun load(): List<Game> {
        val raw = prefs.getString(KEY, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { fromJson(arr.getJSONObject(it)) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(games: List<Game>) {
        val arr = JSONArray()
        games.forEach { arr.put(toJson(it)) }
        prefs.edit().putString(KEY, arr.toString()).apply()
    }

    fun importGame(uri: Uri): Game {
        try {
            context.contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (e: SecurityException) {
            // Nem todo provedor permite permissão persistente; seguimos sem ela.
        }
        val fileName = queryName(uri) ?: uri.lastPathSegment?.substringAfterLast('/') ?: "Jogo"
        val ext = fileName.substringAfterLast('.', "").uppercase()
        val game = Game(
            id = UUID.randomUUID().toString(),
            name = fileName.substringBeforeLast('.'),
            uri = uri.toString(),
            fileType = ext.ifEmpty { "ARQ" },
            addedAt = System.currentTimeMillis()
        )
        prefixDir(game.id).mkdirs()
        return game
    }

    fun remove(game: Game) {
        prefixDir(game.id).deleteRecursively()
        try {
            context.contentResolver.releasePersistableUriPermission(
                Uri.parse(game.uri), Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (e: Exception) {
            // Sem permissão persistente para liberar.
        }
    }

    private fun queryName(uri: Uri): String? = try {
        context.contentResolver.query(
            uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null
        )?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
    } catch (e: Exception) {
        null
    }

    private fun toJson(g: Game) = JSONObject().apply {
        put("id", g.id)
        put("name", g.name)
        put("uri", g.uri)
        put("fileType", g.fileType)
        put("addedAt", g.addedAt)
        put("graphics", g.profile.graphics.name)
        put("resolution", g.profile.resolution.name)
        put("controlsLayout", g.profile.controlsLayout)
    }

    private fun fromJson(o: JSONObject) = Game(
        id = o.getString("id"),
        name = o.getString("name"),
        uri = o.getString("uri"),
        fileType = o.optString("fileType", "ARQ"),
        addedAt = o.optLong("addedAt", 0L),
        profile = GameProfile(
            graphics = runCatching { GraphicsApi.valueOf(o.optString("graphics")) }
                .getOrDefault(GraphicsApi.AUTO),
            resolution = runCatching { Resolution.valueOf(o.optString("resolution")) }
                .getOrDefault(Resolution.NATIVE),
            controlsLayout = o.optString("controlsLayout", "Padrão")
        )
    )

    private companion object {
        const val KEY = "games"
    }
}
