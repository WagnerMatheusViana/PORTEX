package com.portex.launcher.data

enum class GraphicsApi(val label: String) {
    AUTO("Automático"),
    DXVK("DXVK (DirectX 9/10/11)"),
    VKD3D("VKD3D-Proton (DirectX 12)"),
    VIRGL("VirGL")
}

enum class Resolution(val label: String) {
    NATIVE("Nativa do aparelho"),
    P720("1280×720"),
    P540("960×540")
}

data class GameProfile(
    val graphics: GraphicsApi = GraphicsApi.AUTO,
    val resolution: Resolution = Resolution.NATIVE,
    val controlsLayout: String = "Padrão"
)

data class Game(
    val id: String,
    val name: String,
    val uri: String,
    val fileType: String,
    val addedAt: Long,
    val profile: GameProfile = GameProfile()
)
