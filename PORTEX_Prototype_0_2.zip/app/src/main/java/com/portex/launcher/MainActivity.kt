package com.portex.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp
import com.portex.launcher.data.Game
import com.portex.launcher.data.GameProfile
import com.portex.launcher.data.GameRepository
import com.portex.launcher.ui.HomeScreen
import com.portex.launcher.ui.LibraryScreen
import com.portex.launcher.ui.PlaceholderScreen
import com.portex.launcher.ui.PortexColors
import com.portex.launcher.ui.PortexTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PortexApp() }
    }
}

private enum class Page(val label: String, val icon: ImageVector) {
    Home("Início", Icons.Default.Home),
    Library("Biblioteca", Icons.Default.SportsEsports),
    Controls("Controles", Icons.Default.Gamepad),
    Settings("Ajustes", Icons.Default.Settings)
}

@Composable
fun PortexApp() {
    val context = LocalContext.current
    val repo = remember { GameRepository(context) }
    val games = remember { mutableStateListOf<Game>().apply { addAll(repo.load()) } }
    var page by rememberSaveable { mutableStateOf(Page.Home) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            if (games.none { it.uri == uri.toString() }) {
                games.add(0, repo.importGame(uri))
                repo.save(games.toList())
            }
            page = Page.Library
        }
    }
    val openPicker = { picker.launch(arrayOf("*/*")) }

    PortexTheme {
        Scaffold(
            containerColor = PortexColors.Bg,
            bottomBar = {
                NavigationBar(containerColor = PortexColors.Panel, contentColor = Color.White) {
                    Page.values().forEach { item ->
                        NavigationBarItem(
                            selected = page == item,
                            onClick = { page = item },
                            icon = { Icon(item.icon, contentDescription = item.label) },
                            label = { Text(item.label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.White,
                                selectedTextColor = Color.White,
                                indicatorColor = PortexColors.Accent
                            )
                        )
                    }
                }
            }
        ) { padding ->
            val m = Modifier.fillMaxSize().padding(padding)
            when (page) {
                Page.Home -> HomeScreen(games.size, openPicker, m)
                Page.Library -> LibraryScreen(
                    games = games,
                    onImport = openPicker,
                    onUpdateProfile = { game: Game, profile: GameProfile ->
                        val i = games.indexOfFirst { it.id == game.id }
                        if (i >= 0) {
                            games[i] = game.copy(profile = profile)
                            repo.save(games.toList())
                        }
                    },
                    onRemove = { game: Game ->
                        repo.remove(game)
                        games.removeAll { it.id == game.id }
                        repo.save(games.toList())
                    },
                    modifier = m
                )
                Page.Controls -> PlaceholderScreen(
                    eyebrow = "CONTROLES NA TELA",
                    title = "Monte seu layout ideal.",
                    body = "O editor de controles ainda está em desenvolvimento.",
                    planned = listOf(
                        "Arrastar e posicionar botões",
                        "Redimensionar analógicos",
                        "Um layout diferente para cada jogo"
                    ),
                    modifier = m
                )
                Page.Settings -> PlaceholderScreen(
                    eyebrow = "CONFIGURAÇÕES",
                    title = "Ajuste sua experiência.",
                    body = "As configurações globais chegam nas próximas versões.",
                    planned = listOf(
                        "Driver gráfico padrão",
                        "Armazenamento dos jogos",
                        "Aparência do launcher"
                    ),
                    modifier = m
                )
            }
        }
    }
}
