package com.portex.launcher.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object PortexColors {
    val Bg = Color(0xFF090B12)
    val Panel = Color(0xFF151A27)
    val Accent = Color(0xFF8B5CF6)
    val AccentSoft = Color(0xFFB9A0FF)
    val Muted = Color(0xFF9299AA)
    val Danger = Color(0xFFFF6B6B)
}

@Composable
fun PortexTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = PortexColors.Accent,
            background = PortexColors.Bg,
            surface = PortexColors.Panel,
            onBackground = Color.White,
            onSurface = Color.White
        ),
        content = content
    )
}
