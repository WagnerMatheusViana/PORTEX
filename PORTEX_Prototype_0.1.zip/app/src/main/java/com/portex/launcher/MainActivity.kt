package com.portex.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF090B12)
private val Panel = Color(0xFF151A27)
private val Accent = Color(0xFF8B5CF6)
private val Muted = Color(0xFF9299AA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PortexApp() }
    }
}

@Composable
fun PortexApp() {
    var page by remember { mutableStateOf("Início") }
    var importedName by remember { mutableStateOf<String?>(null) }
    var selectedFile by remember { mutableStateOf("Nenhum jogo importado") }
    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let {
            selectedFile = it.lastPathSegment?.substringAfterLast('/') ?: "Arquivo selecionado"
            importedName = selectedFile
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Accent, background = Bg, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Color.White) {
                    listOf("Início", "Biblioteca", "Controles", "Ajustes").forEach { item ->
                        NavigationBarItem(
                            selected = page == item,
                            onClick = { page = item },
                            icon = {
                                Icon(
                                    when (item) {
                                        "Início" -> Icons.Default.Home
                                        "Biblioteca" -> Icons.Default.SportsEsports
                                        "Controles" -> Icons.Default.Gamepad
                                        else -> Icons.Default.Settings
                                    }, contentDescription = item
                                )
                            },
                            label = { Text(item, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.White,
                                selectedTextColor = Color.White,
                                indicatorColor = Accent
                            )
                        )
                    }
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Spacer(Modifier.height(18.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("PORTEX", fontSize = 27.sp, fontWeight = FontWeight.Black, color = Color.White)
                            Text("ANDROID GAME HUB  •  PREVIEW 0.1", fontSize = 9.sp, color = Muted, letterSpacing = 1.4.sp)
                        }
                        Surface(shape = RoundedCornerShape(50), color = Color(0xFF20263A)) {
                            Text("●  DEMO", color = Color(0xFFB9A0FF), modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), fontSize = 10.sp)
                        }
                    }
                }
                item {
                    Surface(color = Panel, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(when(page) {
                                "Início" -> "SEU PRÓXIMO JOGO COMEÇA AQUI"
                                "Biblioteca" -> "SUA BIBLIOTECA"
                                "Controles" -> "CONTROLES NA TELA"
                                else -> "CONFIGURAÇÕES"
                            }, color = Muted, fontSize = 10.sp, letterSpacing = 1.2.sp)
                            Text(when(page) {
                                "Início" -> "Jogue do seu jeito."
                                "Biblioteca" -> "Seus jogos, em um só lugar."
                                "Controles" -> "Monte seu layout ideal."
                                else -> "Ajuste sua experiência."
                            }, color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                            Text("Uma interface experimental para organizar e preparar jogos no Android.", color = Muted, fontSize = 13.sp)
                            Button(
                                onClick = { picker.launch(arrayOf("*/*")) },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = Accent),
                                shape = RoundedCornerShape(13.dp)
                            ) {
                                Icon(Icons.Default.Add, null)
                                Spacer(Modifier.width(8.dp))
                                Text("IMPORTAR ARQUIVO")
                            }
                        }
                    }
                }
                item {
                    Text("VISÃO GERAL", color = Muted, fontSize = 11.sp, letterSpacing = 1.3.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        StatCard("JOGOS", if (importedName == null) "00" else "01", Modifier.weight(1f))
                        StatCard("PERFIL", "PADRÃO", Modifier.weight(1f))
                        StatCard("MOTOR", "DEMO", Modifier.weight(1f))
                    }
                }
                item {
                    Text("BIBLIOTECA", color = Muted, fontSize = 11.sp, letterSpacing = 1.3.sp)
                    Surface(color = Panel, shape = RoundedCornerShape(17.dp), modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                            Surface(color = Color(0xFF29213F), shape = RoundedCornerShape(12.dp)) {
                                Icon(Icons.Default.SportsEsports, null, tint = Accent, modifier = Modifier.padding(13.dp).size(25.dp))
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(importedName ?: "Nenhum jogo adicionado", fontWeight = FontWeight.SemiBold, color = Color.White)
                                Text(if (importedName == null) "Importe arquivos para começar" else "Arquivo selecionado • não executável nesta demo", color = Muted, fontSize = 11.sp)
                            }
                            Icon(Icons.Default.ChevronRight, null, tint = Muted)
                        }
                    }
                }
                item {
                    Text("STATUS DO PROJETO", color = Muted, fontSize = 11.sp, letterSpacing = 1.3.sp)
                    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        StatusRow("Interface PORTEX", "PRONTA", true)
                        StatusRow("Importação de arquivos", "DEMO", true)
                        StatusRow("Controles virtuais", "EM DESENVOLVIMENTO", false)
                        StatusRow("Wine / Box64", "NÃO INTEGRADO", false)
                        StatusRow("Execução de jogos Windows", "NÃO DISPONÍVEL", false)
                    }
                }
                item {
                    Text("PORTEX  •  CONCEITO INICIAL", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(vertical = 12.dp))
                }
            }
        }
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier = modifier, color = Panel, shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(12.dp)) {
            Text(title, color = Muted, fontSize = 9.sp)
            Spacer(Modifier.height(5.dp))
            Text(value, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun StatusRow(name: String, status: String, ready: Boolean) {
    Row(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(name, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Text(status, color = if (ready) Color(0xFFB9A0FF) else Muted, fontSize = 9.sp)
        }
        Icon(if (ready) Icons.Default.CheckCircle else Icons.Default.Schedule, null,
            tint = if (ready) Accent else Muted, modifier = Modifier.size(18.dp))
    }
}
