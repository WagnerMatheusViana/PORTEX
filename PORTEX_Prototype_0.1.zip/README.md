# PORTEX Launcher — Preview 0.1

Protótipo visual Android em Kotlin + Jetpack Compose.

## O que funciona nesta prévia
- Interface inicial e navegação entre abas.
- Seleção/importação de arquivo pelo seletor Android.
- Cartão de biblioteca demonstrativo.
- Painel de status do desenvolvimento.

## O que ainda NÃO funciona
- Não executa arquivos EXE.
- Não inclui Wine, Box64, DXVK ou VKD3D.
- Não possui controles virtuais ativos durante jogos.
- A importação atual apenas seleciona um arquivo e mostra seu nome.

## Como compilar
1. Abra a pasta PORTEX_Prototype no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Use Build > Build Bundle(s) / APK(s) > Build APK(s).
4. O APK de debug ficará em `app/build/outputs/apk/debug/`.

Requer Android Studio com Android SDK 35 e JDK compatível com Android Gradle Plugin 8.7.3.
